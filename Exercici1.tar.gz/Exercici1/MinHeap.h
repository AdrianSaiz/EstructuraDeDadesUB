/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MinHeap.h
 * Author: rballeba50.alumnes
 *
 * Created on 24 / maig / 2016, 12:17
 */

#ifndef MINHEAP_H
#define MINHEAP_H

#include <vector>
#include <string>
#include <iostream>
#include "Position.h"
#include <stdexcept>

using namespace std;

template <class E, class N> class MinHeap {
    public:
        MinHeap() {};
        virtual ~MinHeap() {};
        const int size() const {return this->vectorElems.size();};
        const bool empty() const {return size() == 0;};
        void insert(const E& key, const N& first, const N& second);
        const E& min() const;
        const Position <E,N>* getPosition(const E& element);
        const vector<pair<N, N>> minValues()const ;
        void removeMin();
        void printHeap();
    private:
        vector<Position<E, N>*> vectorElems;
        void upHeap();
        void downHeap();
        void swap (int pos1, int pos2);
};
template <class E, class N> void MinHeap<E, N>::insert(const E& key, const N& first, const N& second) {
    if (empty()) {
        vectorElems.push_back(new Position<E, N>(key));
        vectorElems[0]->newValue(first, second);
    }
    else {
        bool found = false;
        int i = 0;
        while (!found && i < vectorElems.size()) {
            found = vectorElems.at(i)->getKey() == key;
            i++;
        }
        if (!found) {
            vectorElems.push_back(new Position<E, N>(key));
            vectorElems[vectorElems.size()-1]->newValue(first, second);
            upHeap();
        }
        else {
            vectorElems[i-1]->newValue(first, second);
        }
    }
}
template<class E, class N> void MinHeap<E, N>::upHeap() {
    bool found = false;
    int positionToUpHeap = vectorElems.size() - 1;
    while(positionToUpHeap != 0 && !found) {
        if(vectorElems[(positionToUpHeap - 1)/2]->getKey() > vectorElems[positionToUpHeap]->getKey()) {
            swap (positionToUpHeap, (positionToUpHeap  - 1)/2);
            positionToUpHeap = (positionToUpHeap - 1)/2;
        }
        else found = true;
    }
}

template<class E, class N> void MinHeap<E, N>::swap(int pos1, int pos2) {
    Position<E, N>* positionAux = vectorElems[pos1];
    vectorElems[pos1] = vectorElems[pos2];
    vectorElems[pos2] = positionAux;
}

template <class E, class N> const E& MinHeap<E, N>::min() const {
    if (empty()) throw new out_of_range("Heap buit");
    return vectorElems[0]->getKey();
}
template <class E, class N> const vector<pair<N, N>> MinHeap<E, N>::minValues() const {
    if (empty()) throw new out_of_range("Heap buit");
    return vectorElems[0].getValues();
}
template <class E, class N> void MinHeap<E, N>::removeMin() {
    Position<E, N>* positionAux = vectorElems[0];
    vectorElems[0] = vectorElems[vectorElems.size()-1];
    vectorElems[vectorElems.size()-1] = positionAux;
    vectorElems.pop_back();
    downHeap();
}
template <class E, class N> void MinHeap<E, N>::downHeap() {
    int i = 0;
    bool found = false;
    while(i < vectorElems.size() && !found) {
        if (2*i+2 >= vectorElems.size() && 2*i+1 >= vectorElems.size()) {
            found = true;
        }
        else if (2*i+2 >= vectorElems.size()) {
            if (vectorElems[i]->getKey() > vectorElems[2*i+1]->getKey()) {
                swap (2*i+1, i);
                i = 2*i+1;
            }
            else {
                found = true;
            }
        }
        else if (2*i+1 >= vectorElems.size()) {
            if (vectorElems[i]->getKey() > vectorElems[2*i+2]->getKey()) {
                swap (2*i+2, i);
                i = 2*i+2;
            }
            else {
                found = true;
            }
        }
        else {
            if (vectorElems[2*i+2]->getKey() > vectorElems[2*i+1]->getKey()) {
                if (vectorElems[i]->getKey() > vectorElems[2*i+1]->getKey()) {
                    swap (2*i+1, i);
                    i = 2*i+1;
                }
                else {
                    found = true;
                }
            }
            else {
                if (vectorElems[i]->getKey() > vectorElems[2*i+2]->getKey()) {
                    swap (2*i+2, i);
                    i = 2*i+2;
                }
                else {
                    found = true;
                }
            }
        }
    }
}

template <class E, class N> void MinHeap<E, N>::printHeap() {
    Position<E, N>* posAux;
    for (typename vector<Position<E,N>*>::iterator it = vectorElems.begin() ; it != vectorElems.end(); ++it) {
        posAux = *it;
        posAux->toString();
    }
}

template<class E, class N> const Position <E,N>* MinHeap<E, N>::getPosition(const E& element) {
    bool found = false;
    int i = 0;
    while (!found && i < vectorElems.size()) {
        found = vectorElems.at(i)->getKey() == element;
        i++;
    }
    if (!found) return nullptr;
    else return vectorElems.at(i-1);
}
#endif /* MINHEAP_H */

