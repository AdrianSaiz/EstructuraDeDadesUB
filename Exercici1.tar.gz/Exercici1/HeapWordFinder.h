/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   HeapWordFinder.h
 * Author: orabasal15.alumnes
 *
 * Created on 25 / maig / 2016, 18:35
 */

#ifndef HEAPWORDFINDER_H
#define HEAPWORDFINDER_H

#include <string>
#include "MinHeap.h"
#include <vector>

using namespace std;

class HeapWordFinder {
public:
    HeapWordFinder() {};
    virtual ~HeapWordFinder() {};
    void appendText(const string filename);
    void insertWord(const string word, int line, int  position);
    const vector<pair<int, int>> findOccurrences(const string word);
    void viewIndex() const;
private:
    MinHeap <string,int> heap;
};

#endif /* HEAPWORDFINDER_H */

