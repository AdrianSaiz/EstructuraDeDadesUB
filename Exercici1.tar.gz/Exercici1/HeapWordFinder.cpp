/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   HeapWordFinder.cpp
 * Author: orabasal15.alumnes
 * 
 * Created on 25 / maig / 2016, 18:35
 */

#include "HeapWordFinder.h"
#include <fstream>
#include <regex>

void HeapWordFinder::appendText(const string filename) {
    ifstream file(filename);
    if (file.fail()) throw runtime_error("El fitxer no existeix");
    else {
        string stringAux, stringAux2;
        int numParaula ,numLinia = 0;
        while(getline(file, stringAux)) {
            stringAux.erase (remove_if (stringAux.begin(), stringAux.end(), ::ispunct), stringAux.end()); //It deletes all puntuation marks.
            transform(stringAux.begin(), stringAux.end(), stringAux.begin(), ::tolower); //to lowercase.
            //String stream.
            istringstream iss(stringAux);
            numParaula = 0;
            while(!iss.eof()) {
                iss >> stringAux2;
                //We only insert into BST if the word is not a control char.
                if(stringAux2 != "") insertWord(stringAux2, numLinia, numParaula);
                numParaula++;
            }
            numLinia++;
        }
    }
    file.close(); 
}

void HeapWordFinder::insertWord(const string word, int line, int position) {
    heap.insert(word,line, position);
}

const vector<pair<int, int>> HeapWordFinder::findOccurrences(const string word) {
    //If it doesn't exist then the BST object throws an error.
    if(heap.getPosition(word) != nullptr) {
        return heap.getPosition(word)->getValues();
    }
    else {
        vector<pair<int,int>> aRetornar;
        aRetornar.push_back(make_pair(-1,-1));
        return aRetornar;
    } 
}

void HeapWordFinder::viewIndex() const {
    MinHeap<string,int> aux = heap;
    
    while (!aux.empty()) {
        aux.getPosition(aux.min())->toString();
        aux.removeMin();
    }
}