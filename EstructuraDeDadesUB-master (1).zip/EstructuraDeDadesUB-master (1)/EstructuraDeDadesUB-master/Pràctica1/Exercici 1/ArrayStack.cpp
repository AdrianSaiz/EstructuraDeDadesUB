#include "ArrayStack.h"
#include <vector>
#include <stdexcept>
#include <iostream>

using namespace std;

ArrayStack::ArrayStack () {
   t = 0; //Initialize top Stack to -1
   data = vector <char> (MAX_STACK);
}

ArrayStack::~ArrayStack() {  
}

bool ArrayStack::empty() {
    return (t == 0);
}

bool ArrayStack::full() {
    return (t == data.max_size()); //Actual size is t+1
}

void ArrayStack::pop() {
    if (!empty()) {
        data.pop_back();
        t--;
    }
    else {
        throw out_of_range("The stack is empty");
    }
}

void ArrayStack::push(const char item) {
    if (!full()) {
        data[t] = item;
        t++;
    }
    else{
        throw out_of_range("The stack is full");
    }
}

char ArrayStack::top() {
    if (!empty()) {
        return data[t];
    }
    else {
        throw out_of_range("The stack is empty");
    }
}

void ArrayStack::print() {
    vector<char>::iterator it = data.begin();
    for(int i= 0 ; i < t; i++) {
        cout << *it << endl;
        it++;
    }
    //We print the last element
    cout << *it << endl;
}