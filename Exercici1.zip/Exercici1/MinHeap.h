/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MinHeap.h
 * Author: rballeba50.alumnes
 *
 * Created on 24 / maig / 2016, 12:17
 */

#ifndef MINHEAP_H
#define MINHEAP_H

#include Position;
#include <vector>
#include <string>
#include <iostream>
#include "Position.h"
#include <stdexcept>

using namespace std;

template <class E, class N> class MinHeap {
    public:
        MinHeap() {size = 0; };
        virtual ~MinHeap();
        const int size() const {return this->size; };
        const bool empty() const {return size() == 0;};
        void insert(const E& key, const N& first, const N& second);
        const E* min() const;
        const vector<pair<N, N>> minValues()const ;
        void removeMin();
        void printHeap() const;
    private:
        vector<Position<E, N>> vectorElems;
        void upHeap(int positionToUpHeap);
        void downHeap();
        int size;
        int lastInPosition;
};
template <class E, class N> void MinHeap<E, N>::insert(const E& key, const N& first, const N& second) {
    if(empty()) {
        vectorElems[0] = new Position<E, N>(key);
        vectorElems[0].newValue(first, second);
        lastInPosition = 0;
        size++;
    }
    else {
        bool found =  false;
        while(lastInPosition != 0 && !found) {
        //Primer anem al pare:
        lastInPosition = (lastInPosition - 1)/2;
        //Comprovem que no té fill dret buit, si té llavors hem trobat
        found = (vectorElems[2*lastInPosition + 2] == 0);
        }
        if(lastInPosition == 0) lastInPosition = 2; //Fill dret de l'arrel.
        while(!found) {
            if(vectorElems[lastInPosition] != 0) lastInPosition = 2*lastInPosition +1;
            else found = true;
        }
        //Ara tenim a lastInPosition la posició on hem d'inserir.
        vectorElems[lastInPosition] = new Position<E, N>(key);
        vectorElems[lastInPosition].newValue(first, second);
        lastInPosition++; //Primero hay que ver
        size++;
        upHeap(lastInPosition);
    }
}
template<class E, class N> void MinHeap<E, N>::upHeap(int positionToUpHeap) {
    bool found = false;
    while(positionToUpHeap != 0 && found) {
        if(vectorElems[(lastInPosition - 1)/2] < vectorElems[lastInPosition]) {
            Position<E, N> positionAux = vectorElems[(lastInPosition - 1)/2];
            vectorElems[(lastInPosition - 1)/2] = vectorElems[lastInPosition];
            vectorElems[lastInPosition] = positionAux;
            lastInPosition = (lastInPosition - 1)/2;
        }
        else found = true;
    }
}
template <class E, class N> const E* MinHeap<E, N>::min() const {
    if (empty()) throw new out_of_range("Heap buit");
    return vectorElems[0].getKey();
}
template <class E, class N> const vector<pair<N, N>> MinHeap<E, N>::minValues() const {
    if (empty()) throw new out_of_range("Heap buit");
    return vectorElems[0].getValues();
}
template <class E, class N> void MinHeap<E, N>::removeMin() {
    Position<E, N> positionAux = vectorElems[0];
    vectorElems[0] = vectorElems[lastInPosition];
    vectorElems[lastInPosition] = positionAux;
    //POR HACER
    downHeap();
}
template <class E, class N> void MinHeap<E, N>::downHeap() {}

template <class E, class N> void MinHeap<E, N>::printHeap() const {
    for(vector<Position>::const_iterator it = vectorElems.begin(); it != vectorElems.end(); ++it) {
        cout << it->toString() << endl;
    }
}
#endif /* MINHEAP_H */

