#ifndef POSITION_H
#define POSITION_H

#include <vector>
#include <string>

using namespace std;

template <class E, class N> class Position {
    public:
        Position(E key);
        virtual ~Position();
        const E& getKey() const;
        void newValue(const N& first, const N& second);
        string toString() const;
        const vector<pair<N,N>> getValues() const;
    private:
        E key;
        vector<pair<N, N>> values;
};

template <class E, class N>  Position<E, N>::Position(E key) {
    this->key = key;
}
template <class E, class N> const E& Position<E,N>::getKey() const {
    return this->key;
}
template <class E, class N> void Position<E, N>::newValue(const N& first, const N& second) {
    vector.push_back(make_pair(first, second));
}
template <class E, class N> string Position<E, N>::toString() const {
    string toReturn;
    toReturn = "Key:" + this->key + "\n Values:";
    for(vector<pair<N,N>>::const_iterator it = values.begin(); it!= values.end(); it++) {
        toReturn += "(" + it->first + "," + it->second + ")";
        if(it!= values.end()) toReturn += ",";
    }
    return toReturn;
}
template <class E, class N> const vector<pair<N,N>> Position<E, N>::getValues() const {
    return values;
}

#endif /* POSITION_H */

